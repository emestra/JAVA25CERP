public class Prueba {
    public static void main(String[] args) {
        Articulo a1 = new Articulo(500);
        Nacional n1 = new Nacional(800, true, "Interior");
        Nacional n2 = new Nacional(800, false, "Interior");
        Nacional n3 = new Nacional(800, false, "Montevideo");
        Importado i1 = new Importado(1000, 300, 2007);
        Importado i2 = new Importado(1000, 300, 2012);

        System.out.println("Artículo genérico: $" + a1.getPrecioVenta());
        System.out.println("Nacional subsidiado (Interior): $" + n1.getPrecioVenta());
        System.out.println("Nacional no subsidiado (Interior): $" + n2.getPrecioVenta());
        System.out.println("Nacional no subsidiado (Montevideo): $" + n3.getPrecioVenta());
        System.out.println("Importado antes de 2008: $" + i1.getPrecioVenta());
        System.out.println("Importado después de 2008: $" + i2.getPrecioVenta());
    }
}