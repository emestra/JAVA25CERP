public class Importado extends Articulo {
    private double impuesto;
    private int añoImportacion;

    public Importado(double precioCosto, double impuesto, int añoImportacion) {
        super(precioCosto);
        this.impuesto = impuesto;
        this.añoImportacion = añoImportacion;
    }

    @Override
    public double getPrecioVenta() {
        double precioBase = super.getPrecioVenta();
        if (añoImportacion <= 2008) {
            return precioBase + (impuesto * 0.80);
        } else {
            return precioBase + impuesto;
        }
    }
}