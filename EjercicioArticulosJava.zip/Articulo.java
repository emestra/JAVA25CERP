public class Articulo {
    protected double precioCosto;

    public Articulo(double precioCosto) {
        this.precioCosto = precioCosto;
    }

    public double getPrecioVenta() {
        return precioCosto * 1.20;
    }
}