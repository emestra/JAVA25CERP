public class Nacional extends Articulo {
    private boolean subsidiado;
    private String region;

    public Nacional(double precioCosto, boolean subsidiado, String region) {
        super(precioCosto);
        this.subsidiado = subsidiado;
        this.region = region;
    }

    @Override
    public double getPrecioVenta() {
        double precioBase = super.getPrecioVenta();
        if (subsidiado) {
            return precioBase;
        } else {
            if (region.equalsIgnoreCase("Interior")) {
                return precioBase * 1.10;
            } else if (region.equalsIgnoreCase("Montevideo")) {
                return precioBase * 1.15;
            }
        }
        return precioBase;
    }
}